from django.db import models


# Create your models here.

class Blog(models.Model):
    blog_id = models.AutoField
    blog_name = models.CharField(max_length=100, default="")
    updated = models.DateField()
    text = models.CharField(max_length=500, default="")
    category = models.CharField(max_length=50, default="")
    link = models.CharField(max_length=100, default="")

    def __str__(self):
        return self.blog_name

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='CourseHome'),
    path('search_course/', views.search, name='SearchCourse'),
]

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='blog'),
    path('search_blog/', views.search, name='SearchBlog')
]

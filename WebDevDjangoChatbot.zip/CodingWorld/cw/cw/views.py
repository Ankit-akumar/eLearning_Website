from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout


def home(request):
    return render(request, 'home.html')


def about(request):
    return render(request, 'aboutus.html')


def handleSignup(request):
    if request.method == "POST":

        # Get the post parameters

        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']
        email = request.POST['email']

        # Check for erroneous inputs

        if len(username) > 15:
            messages.warning(request, "Username must have less than 15 characters!")
            return redirect('home')

        if User.objects.filter(username=username).exists():
            messages.warning(request, "Username already exists!")
            return redirect('home')

        if not username.isalnum():
            messages.warning(request, "Username must contain only alpha numeric characters!")
            return redirect('home')

        if pass1 != pass2:
            messages.warning(request, "Passwords do not match!")
            return redirect('home')

        if len(pass1) < 5:
            messages.warning(request, "Password must contain at least 5 characters!")
            return redirect('home')

        # Create the user

        myuser = User.objects.create_user(username, email, pass1)
        myuser.first_name = fname
        myuser.last_name = lname
        myuser.save()
        messages.success(request, "Your account has been created successfully")
        return redirect('home')

    else:
        return HttpResponse('404 - Not Found')


def handleLogin(request):
    if request.method == "POST":
        loginusername = request.POST['loginusername']
        loginpass = request.POST['loginpass']
        user = authenticate(username=loginusername, password=loginpass)

        if user is not None:
            login(request, user)
            messages.success(request, "Logged In Successfully!")
            return redirect('home')
        else:
            messages.warning(request, "Login Failed (Invalid Credentials)!")
            return redirect('home')

    return HttpResponse('404 - Not Found')


def handleLogout(request):
    logout(request)
    messages.success(request, 'Logged Out Successfully!')
    return redirect('home')


def forgot(request):
    return render(request, 'forgot.html')


def reset(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        u = User.objects.get(username=username)
        if u is not None:
            if u.email == email:
                return render(request, 'reset.html')
            else:
                messages.warning(request, "Invalid answer")
                return redirect('forgot')
        else:
            messages.warning(request, "User does not exists")
            return redirect('forgot')
    else:
        return HttpResponse('404 - Not Found')


def resetSuccess(request):
    if request.method == 'POST':
        username = request.POST['username']
        newpassword = request.POST['pass1']
        newpassword2 = request.POST['pass2']
        if newpassword != newpassword2:
            messages.warning(request, 'Passwords are not matching')
            return redirect('reset')
        u = User.objects.get(username=username)
        if u is not None:
            u.set_password(newpassword)
            u.save()
            messages.success(request, 'Password reset successfully!')
            return redirect('home')
        else:
            messages.warning(request, 'Enter the username registered with us')
            return redirect('reset')
    else:
        return HttpResponse('404 - Not Found')

from django.shortcuts import render
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer

# Create your views here.

# CHAT BOT

chatbot = ChatBot(
    'Lita',
    storage_adapter='chatterbot.storage.SQLStorageAdapter',
    logic_adapters=[
        'chatterbot.logic.MathematicalEvaluation',
        'chatterbot.logic.TimeLogicAdapter',
        'chatterbot.logic.BestMatch',
        {
            'import_path': 'chatterbot.logic.BestMatch',
            'default_response': 'I am sorry, but I do not understand. I am still learning.',
            'maximum_similarity_threshold': 0.90
        }
    ],
    database_uri='sqlite:///db.sqlite3'
)

training_data_quesans = open('training_data/ques_ans.txt').read().splitlines()
training_data_personal = open('training_data/personal_ques.txt').read().splitlines()

training_data = training_data_quesans + training_data_personal

trainer = ListTrainer(chatbot)


# trainer.train(training_data)


def helping(request):
    if request.method == 'POST':
        usertext = request.POST['usertext']
        if usertext:
            response = chatbot.get_response(usertext)
            # if response is 'default_response':
            #     response = "Sorry! Can't help you with that. :("
            #     return render(request, 'help.html', {'response': response})
            return render(request, 'help.html', {'response': response})
        else:
            response = "Sorry! Can't help you with that. :("
            return render(request, 'help.html', {'response': response})
    else:
        return render(request, 'help.html')

from django.shortcuts import render
from .models import Blog
from django.db.models import Q
from django.http import *


# Create your views here.

def index(request):
    blogs = Blog.objects.all()
    params = {'blog': blogs}
    return render(request, 'blogs/blog.html', params)


def search(request):
    if request.method == 'POST':
        srch = request.POST['srh']

        if srch:
            match = Blog.objects.filter(Q(category__icontains=srch))
            if match:
                return render(request, 'searchb.html', {'sr': match})
            else:
                return HttpResponseRedirect('/blogs/')
        else:
            return HttpResponseRedirect('/blogs/')
    return HttpResponse('404 - Not Found')

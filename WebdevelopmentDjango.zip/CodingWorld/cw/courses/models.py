from django.db import models


# Create your models here.
class Course(models.Model):
    course_id = models.AutoField
    course_name = models.CharField(max_length=50)
    desc = models.CharField(max_length=300)
    updated = models.DateField()
    rating = models.DecimalField(max_digits=5, decimal_places=1, default=0.0)
    price = models.IntegerField(default=0)
    category = models.CharField(max_length=50, default="")
    image = models.ImageField(upload_to="courses/images", default="")

    def __str__(self):
        return self.course_name

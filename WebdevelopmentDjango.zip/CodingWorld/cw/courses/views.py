from django.shortcuts import render
from django.http import *
from .models import Course
from django.db.models import Q


# Create your views here.
def index(request):
    courses = Course.objects.all()
    params = {'course': courses}
    return render(request, 'courses/index.html', params)


def search(request):
    if request.method == 'POST':
        srch = request.POST['srh']

        if srch:
            match = Course.objects.filter(Q(course_name__icontains=srch) |
                                          Q(category__icontains=srch))
            if match:
                return render(request, 'search.html', {'sr': match})
            else:
                return HttpResponseRedirect('/courses/')
        else:
            return HttpResponseRedirect('/courses/')
    return HttpResponse('404 - Not Found')
